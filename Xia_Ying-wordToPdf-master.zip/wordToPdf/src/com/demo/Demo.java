package com.demo;

import netscape.javascript.JSObject;

import java.util.ArrayList;
import java.util.List;

public class Demo {
    public static void main(String[] args) {
//        List<Long> list = new ArrayList<Long>(7000);
//        list.add(1l);
//        list.add(2l);
//        Integer i = Integer.MAX_VALUE -8;
//        System.out.println(i);
        String s = "{" +
                "\"trans_head\": {" +
                "\"return_code\": \"0000\"," +
                "\"return_msg\": \"代付请求交易成功\"" +
                "}," +
                "\"trans_reqDatas\": {" +
                "\"trans_reqData\": {" +
                "\"trans_endtime\": \"2017-08-22 15:24:49\"," +
                "\"trans_fee\": \"1.00\"," +
                "\"trans_remark\": []," +
                "\"trans_starttime\": \"2017-08-22 15:24:47\"," +
                "\"to_acc_dept\": \"安徽省|合肥市|兴业银行兴业银行合肥政务区支行\"," +
                "\"to_acc_name\": \"田先程\"," +
                "\"to_acc_no\": \"622909493112465315\"," +
                "\"trans_batchid\": \"62283304\"," +
                "\"trans_money\": \"100.00\"," +
                "\"trans_no\": \"XW201708221216597653\"," +
                "\"trans_orderid\": \"72915352\"," +
                "\"trans_summary\": \"小微金融用户2865提现-100.0\"," +
                "\"state\": \"1\"" +
                "}" +
                "}" +
                "}";
        System.out.println(s);

    }
}
